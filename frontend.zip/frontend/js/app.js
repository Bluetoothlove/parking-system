// API基础URL
const API_BASE_URL = 'http://localhost:5000/api';

// 全局变量
let currentUser = null;
let authToken = localStorage.getItem('authToken');
let cameraStream = null;
let currentCameraMode = null;

// ========== 初始化 ==========
document.addEventListener('DOMContentLoaded', () => {
    console.log('智慧停车系统启动...');
    
    // 检查token并自动登录
    if (authToken) {
        checkAuth();
    } else {
        // 未登录时自动显示登录框
        setTimeout(() => {
            showModal('loginModal');
        }, 500);
    }
    
    // 初始化事件监听器
    initEventListeners();
    
    // 加载统计数据
    loadStatistics();
    
    // 设置定时刷新统计
    setInterval(loadStatistics, 30000);
});

function initEventListeners() {
    // 登录/注册相关
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('registerForm').addEventListener('submit', handleRegister);
    document.getElementById('changePasswordForm').addEventListener('submit', handleChangePassword);
    
    // 登出按钮
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    
    // 模态框切换链接
    document.getElementById('showRegisterLink').addEventListener('click', (e) => {
        e.preventDefault();
        hideModal('loginModal');
        showModal('registerModal');
    });
    
    document.getElementById('showLoginLink').addEventListener('click', (e) => {
        e.preventDefault();
        hideModal('registerModal');
        showModal('loginModal');
    });
    
    document.getElementById('showChangePasswordLink').addEventListener('click', (e) => {
        e.preventDefault();
        if (!currentUser) {
            showNotification('请先登录', 'warning');
            showModal('loginModal');
            return;
        }
        showModal('changePasswordModal');
    });
    
    // 上传区域点击
    document.getElementById('parkingUploadArea').addEventListener('click', () => {
        document.getElementById('parkingFile').click();
    });
    
    document.getElementById('plateUploadArea').addEventListener('click', () => {
        document.getElementById('plateFile').click();
    });
    
    // 文件选择
    document.getElementById('parkingFile').addEventListener('change', (e) => {
        handleFileSelect(e, 'parking');
    });
    
    document.getElementById('plateFile').addEventListener('change', (e) => {
        handleFileSelect(e, 'plate');
    });
    
    // 功能按钮
    document.getElementById('parkingDetectBtn').addEventListener('click', detectParking);
    document.getElementById('parkingCameraBtn').addEventListener('click', () => startCamera('parking'));
    document.getElementById('plateRecognizeBtn').addEventListener('click', recognizePlate);
    document.getElementById('plateCameraBtn').addEventListener('click', () => startCamera('plate'));
    
    // 快捷操作
    document.getElementById('manualEntryBtn').addEventListener('click', () => {
        if (!currentUser) {
            showNotification('请先登录', 'warning');
            showModal('loginModal');
            return;
        }
        showModal('entryModal');
    });
    
    document.getElementById('manualExitBtn').addEventListener('click', () => {
        if (!currentUser) {
            showNotification('请先登录', 'warning');
            showModal('loginModal');
            return;
        }
        showModal('exitModal');
    });
    
    document.getElementById('viewRecordsBtn').addEventListener('click', showRecords);
    
    // 入场/出场表单
    document.getElementById('entryForm').addEventListener('submit', handleEntry);
    document.getElementById('exitForm').addEventListener('submit', handleExit);
}

// ========== 用户认证 ==========
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    
    if (!username || !password) {
        showNotification('请输入用户名和密码', 'warning');
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            authToken = data.access_token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            
            updateUserInterface();
            hideModal('loginModal');
            showNotification('登录成功', 'success');
            loadStatistics();
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('登录错误:', error);
        showNotification('登录失败，请检查网络连接', 'error');
    } finally {
        hideLoading();
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const username = document.getElementById('registerUsername').value.trim();
    const password = document.getElementById('registerPassword').value.trim();
    const confirmPassword = document.getElementById('registerConfirmPassword').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    
    if (!username || !password) {
        showNotification('用户名和密码不能为空', 'warning');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('两次输入的密码不一致', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('密码至少需要6个字符', 'warning');
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password, email })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('注册成功，请登录', 'success');
            hideModal('registerModal');
            showModal('loginModal');
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('注册错误:', error);
        showNotification('注册失败，请稍后重试', 'error');
    } finally {
        hideLoading();
    }
}

async function handleChangePassword(e) {
    e.preventDefault();
    
    const oldPassword = document.getElementById('oldPassword').value.trim();
    const newPassword = document.getElementById('newPassword').value.trim();
    const confirmNewPassword = document.getElementById('confirmNewPassword').value.trim();
    
    if (!oldPassword || !newPassword) {
        showNotification('请填写所有密码字段', 'warning');
        return;
    }
    
    if (newPassword !== confirmNewPassword) {
        showNotification('新密码不一致', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showNotification('新密码至少需要6个字符', 'warning');
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/change-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ old_password: oldPassword, new_password: newPassword })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('密码修改成功', 'success');
            hideModal('changePasswordModal');
            document.getElementById('changePasswordForm').reset();
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('修改密码错误:', error);
        showNotification('修改密码失败', 'error');
    } finally {
        hideLoading();
    }
}

function handleLogout() {
    if (authToken) {
        fetch(`${API_BASE_URL}/auth/logout`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        }).finally(() => {
            authToken = null;
            currentUser = null;
            localStorage.removeItem('authToken');
            updateUserInterface();
            showNotification('已退出登录', 'info');
            showModal('loginModal');
        });
    }
}

async function checkAuth() {
    if (!authToken) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/me`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.user;
            updateUserInterface();
        } else {
            localStorage.removeItem('authToken');
            authToken = null;
        }
    } catch (error) {
        console.error('认证检查失败:', error);
        localStorage.removeItem('authToken');
        authToken = null;
    }
}

function updateUserInterface() {
    const userDisplay = document.getElementById('userDisplay');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const userMenu = document.getElementById('userMenu');
    
    if (currentUser) {
        userDisplay.textContent = `${currentUser.username} (${currentUser.role === 'admin' ? '管理员' : '普通用户'})`;
        loginBtn.style.display = 'none';
        logoutBtn.style.display = 'inline-block';
        if (userMenu) userMenu.style.display = 'block';
        
        // 启用功能按钮
        document.getElementById('parkingDetectBtn').disabled = false;
        document.getElementById('plateRecognizeBtn').disabled = false;
        document.getElementById('manualEntryBtn').disabled = false;
        document.getElementById('manualExitBtn').disabled = false;
        document.getElementById('viewRecordsBtn').disabled = false;
    } else {
        userDisplay.textContent = '未登录';
        loginBtn.style.display = 'inline-block';
        logoutBtn.style.display = 'none';
        if (userMenu) userMenu.style.display = 'none';
        
        // 禁用功能按钮
        document.getElementById('parkingDetectBtn').disabled = true;
        document.getElementById('plateRecognizeBtn').disabled = true;
        document.getElementById('manualEntryBtn').disabled = true;
        document.getElementById('manualExitBtn').disabled = true;
        document.getElementById('viewRecordsBtn').disabled = true;
    }
}

// ========== 统计信息 ==========
async function loadStatistics() {
    if (!authToken || !currentUser) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/statistics`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('todayIncome').textContent = data.statistics.today_income.toFixed(2);
            document.getElementById('currentVehicles').textContent = data.statistics.current_vehicles;
            document.getElementById('availableSpaces').textContent = data.statistics.available_spaces;
            document.getElementById('totalSpaces').textContent = data.statistics.total_spaces;
        }
    } catch (error) {
        console.error('加载统计失败:', error);
    }
}

// ========== 文件处理 ==========
function handleFileSelect(event, mode) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
        if (mode === 'parking') {
            document.getElementById('parkingPreview').style.display = 'block';
            document.getElementById('parkingPreviewImg').src = e.target.result;
            document.getElementById('parkingDetectBtn').disabled = false;
        } else {
            document.getElementById('platePreview').style.display = 'block';
            document.getElementById('platePreviewImg').src = e.target.result;
            document.getElementById('plateRecognizeBtn').disabled = false;
        }
    };
    reader.readAsDataURL(file);
}

// ========== 停车位检测 ==========
async function detectParking() {
    if (!currentUser) {
        showNotification('请先登录', 'warning');
        showModal('loginModal');
        return;
    }
    
    const file = document.getElementById('parkingFile').files[0];
    if (!file) {
        showNotification('请先选择图片', 'warning');
        return;
    }
    
    showLoading();
    
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        const response = await fetch(`${API_BASE_URL}/parking/detect`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        
        if (response.status === 401 || response.status === 422) {
            showNotification('登录已过期，请重新登录', 'warning');
            localStorage.removeItem('authToken');
            currentUser = null;
            updateUserInterface();
            showModal('loginModal');
            return;
        }
        
        const data = await response.json();
        
        if (data.success) {
            showResults(data);
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('检测失败:', error);
        showNotification('检测失败，请稍后重试', 'error');
    } finally {
        hideLoading();
    }
}

// ========== 车牌识别 ==========
async function recognizePlate() {
    if (!currentUser) {
        showNotification('请先登录', 'warning');
        showModal('loginModal');
        return;
    }
    
    const file = document.getElementById('plateFile').files[0];
    if (!file) {
        showNotification('请先选择图片', 'warning');
        return;
    }
    
    showLoading();
    
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        const response = await fetch(`${API_BASE_URL}/plate/recognize`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        
        if (response.status === 401 || response.status === 422) {
            showNotification('登录已过期，请重新登录', 'warning');
            localStorage.removeItem('authToken');
            currentUser = null;
            updateUserInterface();
            showModal('loginModal');
            return;
        }
        
        const data = await response.json();
        
        if (data.success) {
            showResults(data);
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('识别失败:', error);
        showNotification('识别失败，请稍后重试', 'error');
    } finally {
        hideLoading();
    }
}

// ========== 摄像头功能 ==========
async function startCamera(mode) {
    if (!currentUser) {
        showNotification('请先登录', 'warning');
        showModal('loginModal');
        return;
    }
    
    try {
        cameraStream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
                width: { ideal: 1280 },
                height: { ideal: 720 } 
            } 
        });
        const video = document.getElementById('cameraFeed');
        video.srcObject = cameraStream;
        
        currentCameraMode = mode;
        document.getElementById('cameraTitle').textContent = 
            mode === 'parking' ? '实时停车位检测' : '实时车牌识别';
        showModal('cameraModal');
    } catch (error) {
        console.error('摄像头启动失败:', error);
        showNotification('无法启动摄像头，请检查权限', 'error');
    }
}

function stopCamera() {
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
    }
    hideModal('cameraModal');
}

function captureSnapshot() {
    if (!cameraStream || !currentCameraMode) return;
    
    const video = document.getElementById('cameraFeed');
    const canvas = document.getElementById('cameraCanvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    canvas.toBlob(async (blob) => {
        const file = new File([blob], 'snapshot.jpg', { type: 'image/jpeg' });
        
        if (currentCameraMode === 'parking') {
            await processCameraSnapshot(file, 'parking');
        } else {
            await processCameraSnapshot(file, 'plate');
        }
    }, 'image/jpeg');
}

async function processCameraSnapshot(file, mode) {
    showLoading();
    
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        const endpoint = mode === 'parking' ? '/parking/detect' : '/plate/recognize';
        
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            stopCamera();
            showResults(data);
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('处理失败:', error);
        showNotification('处理失败，请稍后重试', 'error');
    } finally {
        hideLoading();
    }
}

// ========== 车辆记录 ==========
async function handleEntry(e) {
    e.preventDefault();
    
    const plateNumber = document.getElementById('entryPlate').value.trim().toUpperCase();
    const parkingSpace = document.getElementById('entrySpace').value.trim().toUpperCase();
    
    if (!plateNumber) {
        showNotification('请输入车牌号', 'warning');
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/records/entry`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                plate_number: plateNumber,
                parking_space: parkingSpace
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('入场登记成功', 'success');
            hideModal('entryModal');
            document.getElementById('entryForm').reset();
            loadStatistics();
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('登记失败:', error);
        showNotification('登记失败，请稍后重试', 'error');
    } finally {
        hideLoading();
    }
}

async function handleExit(e) {
    e.preventDefault();
    
    const plateNumber = document.getElementById('exitPlate').value.trim().toUpperCase();
    const fee = document.getElementById('exitFee').value;
    
    if (!plateNumber) {
        showNotification('请输入车牌号', 'warning');
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/records/exit`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                plate_number: plateNumber,
                fee: parseFloat(fee) || 0
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('出场登记成功', 'success');
            hideModal('exitModal');
            document.getElementById('exitForm').reset();
            loadStatistics();
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('登记失败:', error);
        showNotification('登记失败，请稍后重试', 'error');
    } finally {
        hideLoading();
    }
}

async function showRecords() {
    if (!currentUser) {
        showNotification('请先登录', 'warning');
        showModal('loginModal');
        return;
    }
    
    showModal('recordsModal');
    document.getElementById('recordsTableBody').innerHTML = '<tr><td colspan="7" class="text-center">加载中...</td></tr>';
    
    try {
        const response = await fetch(`${API_BASE_URL}/records`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            renderRecords(data.records);
        } else {
            document.getElementById('recordsTableBody').innerHTML = 
                '<tr><td colspan="7" class="text-center">加载失败</td></tr>';
        }
    } catch (error) {
        console.error('加载记录失败:', error);
        document.getElementById('recordsTableBody').innerHTML = 
            '<tr><td colspan="7" class="text-center">加载失败</td></tr>';
    }
}

function renderRecords(records) {
    const tbody = document.getElementById('recordsTableBody');
    tbody.innerHTML = '';
    
    if (!records || records.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">暂无记录</td></tr>';
        return;
    }
    
    records.forEach(record => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${record.id}</td>
            <td>${record.plate_number}</td>
            <td>${formatDateTime(record.entry_time)}</td>
            <td>${record.exit_time ? formatDateTime(record.exit_time) : '-'}</td>
            <td>${record.parking_space || '-'}</td>
            <td>${record.fee ? record.fee.toFixed(2) : '0.00'} 元</td>
            <td>${record.status === 'in' ? '在场' : '已离场'}</td>
        `;
        tbody.appendChild(tr);
    });
}

function formatDateTime(datetimeStr) {
    if (!datetimeStr) return '-';
    try {
        const date = new Date(datetimeStr);
        return date.toLocaleString('zh-CN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    } catch {
        return datetimeStr;
    }
}

// ========== 结果显示 ==========
function showResults(data) {
    const resultsSection = document.getElementById('resultsSection');
    const resultImage = document.getElementById('resultImage');
    const resultInfo = document.getElementById('resultInfo');
    
    resultImage.src = `http://localhost:5000${data.result_image}`;
    
    let infoHtml = '<h4>检测结果</h4>';
    
    if (data.detected_objects) {
        infoHtml += `<p>检测到 <strong>${data.count}</strong> 个对象</p>`;
        data.detected_objects.forEach((obj, index) => {
            infoHtml += `
                <div class="info-item">
                    <strong>#${index + 1}</strong><br>
                    类别: ${obj.class}<br>
                    置信度: ${(obj.confidence * 100).toFixed(1)}%
                </div>
            `;
        });
    } else if (data.plates) {
        infoHtml += `<p>检测到 <strong>${data.count}</strong> 个车牌</p>`;
        data.plates.forEach((plate, index) => {
            infoHtml += `
                <div class="info-item">
                    <strong>车牌 ${index + 1}:</strong> ${plate}
                </div>
            `;
        });
    }
    
    resultInfo.innerHTML = infoHtml;
    resultsSection.style.display = 'block';
    
    // 滚动到结果区域
    resultsSection.scrollIntoView({ behavior: 'smooth' });
}

function hideResults() {
    document.getElementById('resultsSection').style.display = 'none';
}

// ========== 模态框控制 ==========
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

// 点击模态框外部关闭
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// ========== 加载动画 ==========
function showLoading() {
    document.getElementById('loadingOverlay').style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loadingOverlay').style.display = 'none';
}

// ========== 通知 ==========
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    
    notification.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s';
        setTimeout(() => {
            if (notification.parentNode) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// 添加淡出动画
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOut {
        from { opacity: 1; transform: translateX(0); }
        to { opacity: 0; transform: translateX(100%); }
    }
`;
document.head.appendChild(style);

// ========== 新增：视频检测功能（两个独立卡片）==========

// 视频相关变量
let videoParkingFile = null;
let videoPlateFile = null;

// 初始化视频事件监听
function initVideoListeners() {
    console.log('初始化视频监听器...');
    
    // 视频停车位检测
    const videoParkingUpload = document.getElementById('videoParkingUploadArea');
    const videoParkingFile = document.getElementById('videoParkingFile');
    const videoParkingDetectBtn = document.getElementById('videoParkingDetectBtn');
    
    if (videoParkingUpload) {
        videoParkingUpload.addEventListener('click', () => {
            document.getElementById('videoParkingFile').click();
        });
    }
    
    if (videoParkingFile) {
        videoParkingFile.addEventListener('change', handleVideoParkingSelect);
    }
    
    if (videoParkingDetectBtn) {
        videoParkingDetectBtn.addEventListener('click', () => detectVideo('parking'));
    }
    
    // 视频车牌识别
    const videoPlateUpload = document.getElementById('videoPlateUploadArea');
    const videoPlateFile = document.getElementById('videoPlateFile');
    const videoPlateRecognizeBtn = document.getElementById('videoPlateRecognizeBtn');
    
    if (videoPlateUpload) {
        videoPlateUpload.addEventListener('click', () => {
            document.getElementById('videoPlateFile').click();
        });
    }
    
    if (videoPlateFile) {
        videoPlateFile.addEventListener('change', handleVideoPlateSelect);
    }
    
    if (videoPlateRecognizeBtn) {
        videoPlateRecognizeBtn.addEventListener('click', () => detectVideo('plate'));
    }
}

// 处理视频停车位文件选择
function handleVideoParkingSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    videoParkingFile = file;
    
    // 显示视频预览
    const videoUrl = URL.createObjectURL(file);
    const videoPlayer = document.getElementById('videoParkingPlayer');
    videoPlayer.src = videoUrl;
    videoPlayer.load();
    
    document.getElementById('videoParkingPreview').style.display = 'block';
    document.getElementById('videoParkingDetectBtn').disabled = false;
    
    showNotification(`已选择视频: ${file.name}`, 'info');
}

// 处理视频车牌文件选择
function handleVideoPlateSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    videoPlateFile = file;
    
    // 显示视频预览
    const videoUrl = URL.createObjectURL(file);
    const videoPlayer = document.getElementById('videoPlatePlayer');
    videoPlayer.src = videoUrl;
    videoPlayer.load();
    
    document.getElementById('videoPlatePreview').style.display = 'block';
    document.getElementById('videoPlateRecognizeBtn').disabled = false;
    
    showNotification(`已选择视频: ${file.name}`, 'info');
}

// 检测视频
async function detectVideo(mode) {
    if (!currentUser) {
        showNotification('请先登录', 'warning');
        showModal('loginModal');
        return;
    }
    
    const file = mode === 'parking' ? videoParkingFile : videoPlateFile;
    const modeText = mode === 'parking' ? '停车位检测' : '车牌识别';
    
    if (!file) {
        showNotification('请先选择视频', 'warning');
        return;
    }
    
    showLoading(`正在${modeText}，请稍候...`);
    
    const formData = new FormData();
    formData.append('video', file);
    
    try {
        const endpoint = mode === 'parking' ? '/parking/detect-video' : '/plate/recognize-video';
        
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        
        if (response.status === 401 || response.status === 422) {
            showNotification('登录已过期，请重新登录', 'warning');
            localStorage.removeItem('authToken');
            currentUser = null;
            updateUserInterface();
            showModal('loginModal');
            return;
        }
        
        const data = await response.json();
        
        if (data.success) {
            showVideoResults(data, mode);
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('视频检测失败:', error);
        showNotification('视频检测失败，请稍后重试', 'error');
    } finally {
        hideLoading();
    }
}

// 显示视频检测结果
function showVideoResults(data, mode) {
    const resultsSection = document.getElementById('resultsSection');
    const resultImage = document.getElementById('resultImage');
    const resultVideoContainer = document.getElementById('resultVideoContainer');
    const resultInfo = document.getElementById('resultInfo');
    
    // 隐藏图片，显示视频
    resultImage.style.display = 'none';
    resultVideoContainer.style.display = 'block';
    resultVideoContainer.innerHTML = '';
    
    if (data.result_video) {
        const videoPlayer = document.createElement('video');
        videoPlayer.src = `http://localhost:5000${data.result_video}`;
        videoPlayer.controls = true;
        videoPlayer.style.width = '100%';
        videoPlayer.style.maxHeight = '400px';
        resultVideoContainer.appendChild(videoPlayer);
    }
    
    const modeText = mode === 'parking' ? '停车位检测' : '车牌识别';
    let infoHtml = `<h4>视频${modeText}结果</h4>`;
    
    // 基本信息
    infoHtml += `<div class="detection-summary">`;
    infoHtml += `<p><strong>处理帧数:</strong> ${data.frames_processed || 0}</p>`;
    
    if (mode === 'parking') {
        infoHtml += `<p><strong>检测到物体:</strong> ${data.total_detections || 0}</p>`;
    } else {
        infoHtml += `<p><strong>识别到车牌:</strong> ${data.unique_plates ? data.unique_plates.length : 0}</p>`;
    }
    infoHtml += `</div>`;
    
    // 车牌列表
    if (mode === 'plate' && data.unique_plates && data.unique_plates.length > 0) {
        infoHtml += '<h5>识别到的车牌:</h5>';
        infoHtml += '<div class="plate-list">';
        data.unique_plates.forEach(plate => {
            infoHtml += `<span class="plate-item">${plate}</span>`;
        });
        infoHtml += '</div>';
    }
    
    // 检测详情（只显示前10帧）
    if (data.detections_per_frame && data.detections_per_frame.length > 0) {
        infoHtml += '<h5>检测详情（前10帧）:</h5>';
        const framesToShow = data.detections_per_frame.slice(0, 10);
        framesToShow.forEach((frame, index) => {
            if (mode === 'parking') {
                infoHtml += `
                    <div class="info-item">
                        <strong>第 ${frame.frame + 1} 帧</strong><br>
                        检测数量: ${frame.count}<br>
                        物体: ${frame.objects ? frame.objects.join(', ') : '无'}
                    </div>
                `;
            } else {
                infoHtml += `
                    <div class="info-item">
                        <strong>第 ${frame.frame + 1} 帧</strong><br>
                        车牌: ${frame.plates && frame.plates.length > 0 ? frame.plates.join(', ') : '无'}
                    </div>
                `;
            }
        });
        if (data.detections_per_frame.length > 10) {
            infoHtml += `<p>... 还有 ${data.detections_per_frame.length - 10} 帧未显示</p>`;
        }
    }
    
    resultInfo.innerHTML = infoHtml;
    resultsSection.style.display = 'block';
    resultsSection.scrollIntoView({ behavior: 'smooth' });
}

// 修改 hideResults 函数
const originalHideResults = hideResults;
hideResults = function() {
    const resultImage = document.getElementById('resultImage');
    const resultVideoContainer = document.getElementById('resultVideoContainer');
    
    resultImage.style.display = 'block';
    resultVideoContainer.style.display = 'none';
    resultVideoContainer.innerHTML = '';
    
    originalHideResults();
};

// 修改 showLoading 支持自定义消息
const originalShowLoading = showLoading;
showLoading = function(message = '处理中...') {
    const overlay = document.getElementById('loadingOverlay');
    const messageEl = overlay.querySelector('p');
    if (messageEl) {
        messageEl.textContent = message;
    }
    overlay.style.display = 'flex';
};

// 修改 updateUserInterface 启用视频按钮
const originalUpdateUserInterface = updateUserInterface;
updateUserInterface = function() {
    originalUpdateUserInterface();
    
    const videoParkingBtn = document.getElementById('videoParkingDetectBtn');
    const videoPlateBtn = document.getElementById('videoPlateRecognizeBtn');
    
    if (currentUser) {
        if (videoParkingBtn) {
            // 如果有文件才启用，否则保持禁用
            videoParkingBtn.disabled = !videoParkingFile;
        }
        if (videoPlateBtn) {
            videoPlateBtn.disabled = !videoPlateFile;
        }
    } else {
        if (videoParkingBtn) videoParkingBtn.disabled = true;
        if (videoPlateBtn) videoPlateBtn.disabled = true;
    }
};

// 在 DOMContentLoaded 后初始化视频监听
document.addEventListener('DOMContentLoaded', () => {
    // 延迟一点初始化，确保DOM完全加载
    setTimeout(initVideoListeners, 200);
});

// 添加视频结果样式
if (!document.querySelector('style[data-video-style]')) {
    const videoStyle = document.createElement('style');
    videoStyle.setAttribute('data-video-style', 'true');
    videoStyle.textContent = `
        .result-video-container {
            width: 100%;
            margin: 10px 0;
        }
        .result-video-container video {
            width: 100%;
            max-height: 400px;
            object-fit: contain;
            border-radius: 8px;
        }
        .plate-list {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 15px 0;
        }
        .plate-item {
            background: #67b3db;
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 1rem;
            font-weight: 500;
        }
        .detection-summary {
            background: #f0f9ff;
            border-left: 4px solid #67b3db;
            padding: 15px;
            margin: 15px 0;
            border-radius: 8px;
        }
        .detection-summary p {
            margin: 5px 0;
            font-size: 1.1rem;
        }
    `;
    document.head.appendChild(videoStyle);
}