import cv2
import numpy as np
from ultralytics import YOLO

class YOLOModel:
    def __init__(self):
        # 加载预训练的YOLO模型
        try:
            self.parking_model = YOLO("./last.pt")
        except:
            print("警告: 无法加载自定义模型，使用默认模型")
            self.parking_model = YOLO('yolov8n.pt')
    
    def predict(self, img, classes=[], conf=0.5):
        if classes:
            results = self.parking_model.predict(img, classes=classes, conf=conf)
        else:
            results = self.parking_model.predict(img, conf=conf)
        return results
    
    def predict_and_detect(self, img, classes=[], conf=0.5, rectangle_thickness=2, text_thickness=1):
        results = self.predict(img, classes, conf=conf)
        
        for result in results:
            for box in result.boxes:
                cv2.rectangle(img, 
                             (int(box.xyxy[0][0]), int(box.xyxy[0][1])),
                             (int(box.xyxy[0][2]), int(box.xyxy[0][3])), 
                             (255, 0, 0), rectangle_thickness)
                cv2.putText(img, f"{result.names[int(box.cls[0])]} {float(box.conf[0]):.2f}",
                           (int(box.xyxy[0][0]), int(box.xyxy[0][1]) - 10),
                           cv2.FONT_HERSHEY_PLAIN, 1, (255, 0, 0), text_thickness)
        
        return img, results