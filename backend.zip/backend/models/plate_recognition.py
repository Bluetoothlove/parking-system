import cv2
import numpy as np
import math
import hyperlpr3 as lpr
from ultralytics import YOLO
from PIL import Image, ImageDraw, ImageFont
import os

class PlateRecognizer:
    def __init__(self):
        try:
            self.license_plate_model = YOLO("./license_plate_detector.pt")
        except:
            print("警告: 无法加载车牌检测模型")
            self.license_plate_model = None
        
        self.catcher = lpr.LicensePlateCatcher()
        self.plate_classNames = ["plate"]
        
        # 加载中文字体
        try:
            font_path = "C:\\Windows\\Fonts\\msyh.ttc"
            self.pil_font = ImageFont.truetype(font_path, 20)
            self.font_available = True
        except:
            print("警告: 无法加载中文字体")
            self.font_available = False
            self.pil_font = ImageFont.load_default()
    
    def add_text_with_background(self, image, text, position, font_face, font_scale, text_color, bg_color, thickness=1, padding=5):
        (text_width, text_height), baseline = cv2.getTextSize(text, font_face, font_scale, thickness)
        box_width = text_width + 2 * padding
        box_height = text_height + 2 * padding + baseline
        x, y = position
        x = max(0, min(x, image.shape[1] - box_width))
        y = max(box_height, min(y, image.shape[0]))
        cv2.rectangle(image, (x, y - box_height), (x + box_width, y), bg_color, -1)
        cv2.putText(image, text, (x + padding, y - padding - baseline), font_face, font_scale, text_color, thickness)
    
    def add_chinese_text_with_background(self, img, text, position, text_color, bg_color):
        img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(img_pil)
        try:
            if self.font_available:
                bbox = draw.textbbox((0, 0), text, font=self.pil_font)
            else:
                bbox = draw.textbbox((0, 0), text)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            x, y = position
            draw.rectangle([x, y, x + text_width + 10, y + text_height + 10], fill=bg_color)
            if self.font_available:
                draw.text((x + 5, y + 5), text, font=self.pil_font, fill=text_color)
            else:
                draw.text((x + 5, y + 5), text, fill=text_color)
            return cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
        except Exception as e:
            print(f"添加中文文本时出错: {e}")
            return img
    
    def recognize(self, image_input):
        try:
            if isinstance(image_input, str):
                img = cv2.imread(image_input)
                if img is None:
                    return None, []
            elif isinstance(image_input, np.ndarray):
                img = image_input
            else:
                return None, []
            
            orig = img.copy()
            
            if self.license_plate_model is None:
                return img, []
            
            results = self.license_plate_model(img)
            detected_plates = []
            
            for r in results:
                boxes = r.boxes
                for box in boxes:
                    x1, y1, x2, y2 = box.xyxy[0]
                    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                    w, h = x2 - x1, y2 - y1
                    conf = math.ceil((box.conf[0] * 100)) / 100
                    
                    cv2.rectangle(img=img, pt1=(x1, y1), pt2=(x1 + w, y1 + h), color=(0, 102, 255), thickness=2)
                    self.add_text_with_background(img, f"plate {conf}", (x1, y1), cv2.FONT_HERSHEY_DUPLEX, 1.1, (255, 255, 255), (0, 102, 255), 1, 5)
                    
                    plate_img = orig[y1:y2, x1:x2]
                    if plate_img.size == 0:
                        continue
                    
                    try:
                        hyperlpr_results = self.catcher(plate_img)
                        if hyperlpr_results:
                            plate_text = hyperlpr_results[0][0]
                            confidence = hyperlpr_results[0][1]
                            detected_plates.append(plate_text)
                            
                            img = self.add_chinese_text_with_background(
                                img,
                                f"车辆进入: {plate_text}",
                                (x1, min(y2 + 30, img.shape[0] - 50)),
                                (255, 255, 255),
                                (0, 102, 255),
                            )
                        else:
                            img = self.add_chinese_text_with_background(
                                img,
                                "识别中...",
                                (x1, min(y2 + 30, img.shape[0] - 50)),
                                (255, 255, 255),
                                (255, 0, 0),
                            )
                    except Exception as e:
                        print(f"HyperLPR识别出错: {e}")
            
            return img, detected_plates
        
        except Exception as e:
            print(f"处理图像时出错: {e}")
            return None, []