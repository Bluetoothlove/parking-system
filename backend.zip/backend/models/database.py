import sqlite3
import datetime

class DatabaseManager:
    def __init__(self, db_path="parking_system.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """初始化数据库表"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 创建车辆进出记录表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vehicle_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL,
                entry_time DATETIME NOT NULL,
                exit_time DATETIME,
                parking_space TEXT,
                duration_minutes INTEGER,
                fee REAL,
                status TEXT DEFAULT 'in',
                operator_id INTEGER
            )
        ''')
        
        # 创建停车位状态表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS parking_spaces (
                space_id TEXT PRIMARY KEY,
                status TEXT DEFAULT 'available',
                vehicle_plate TEXT,
                last_updated DATETIME
            )
        ''')
        
        # 创建系统日志表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME NOT NULL,
                log_type TEXT NOT NULL,
                message TEXT NOT NULL,
                details TEXT,
                user_id INTEGER
            )
        ''')
        
        conn.commit()
        conn.close()
        print("数据库初始化完成")
    
    def add_vehicle_record(self, plate_number, parking_space=None, operator_id=None):
        """添加车辆进入记录"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        entry_time = datetime.datetime.now()
        cursor.execute('''
            INSERT INTO vehicle_records (plate_number, entry_time, parking_space, status, operator_id)
            VALUES (?, ?, ?, 'in', ?)
        ''', (plate_number, entry_time, parking_space, operator_id))
        
        # 更新停车位状态
        if parking_space:
            cursor.execute('''
                INSERT OR REPLACE INTO parking_spaces (space_id, status, vehicle_plate, last_updated)
                VALUES (?, 'occupied', ?, ?)
            ''', (parking_space, plate_number, entry_time))
        
        conn.commit()
        conn.close()
        self.log_system_event("VEHICLE_ENTRY", f"车辆 {plate_number} 进入停车位 {parking_space}", user_id=operator_id)
    
    def update_vehicle_exit(self, plate_number, fee=0, operator_id=None):
        """更新车辆离开记录"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        exit_time = datetime.datetime.now()
        
        # 查找最近的进入记录
        cursor.execute('''
            SELECT id, entry_time, parking_space FROM vehicle_records 
            WHERE plate_number = ? AND status = 'in' 
            ORDER BY entry_time DESC LIMIT 1
        ''', (plate_number,))
        
        record = cursor.fetchone()
        if record:
            record_id, entry_time_str, parking_space = record
            entry_time = datetime.datetime.strptime(entry_time_str, '%Y-%m-%d %H:%M:%S.%f')
            duration = (exit_time - entry_time).total_seconds() / 60
            
            cursor.execute('''
                UPDATE vehicle_records 
                SET exit_time = ?, duration_minutes = ?, fee = ?, status = 'out'
                WHERE id = ?
            ''', (exit_time, duration, fee, record_id))
            
            # 释放停车位
            if parking_space:
                cursor.execute('''
                    UPDATE parking_spaces 
                    SET status = 'available', vehicle_plate = NULL, last_updated = ?
                    WHERE space_id = ?
                ''', (exit_time, parking_space))
            
            conn.commit()
            self.log_system_event("VEHICLE_EXIT", f"车辆 {plate_number} 离开，费用: {fee}元", user_id=operator_id)
        
        conn.close()
    
    def get_parking_statistics(self, days=7):
        """获取停车统计信息"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 今日收入
        cursor.execute('''
            SELECT SUM(fee) FROM vehicle_records 
            WHERE date(exit_time) = date('now') AND fee IS NOT NULL
        ''')
        today_income = cursor.fetchone()[0] or 0
        
        # 当前停车车辆数
        cursor.execute('''
            SELECT COUNT(*) FROM vehicle_records WHERE status = 'in'
        ''')
        current_vehicles = cursor.fetchone()[0]
        
        # 可用停车位
        cursor.execute('''
            SELECT COUNT(*) FROM parking_spaces WHERE status = 'available'
        ''')
        available_spaces = cursor.fetchone()[0] or 0
        
        # 总停车位
        cursor.execute('''
            SELECT COUNT(*) FROM parking_spaces
        ''')
        total_spaces = cursor.fetchone()[0] or 20
        
        conn.close()
        
        return {
            'today_income': float(today_income),
            'current_vehicles': current_vehicles,
            'available_spaces': available_spaces,
            'total_spaces': total_spaces
        }
    
    def log_system_event(self, log_type, message, details=None, user_id=None):
        """记录系统事件"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO system_logs (timestamp, log_type, message, details, user_id)
                VALUES (?, ?, ?, ?, ?)
            ''', (datetime.datetime.now(), log_type, message, details, user_id))
            
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"记录系统事件时出错: {e}")