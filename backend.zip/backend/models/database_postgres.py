import psycopg2
from psycopg2.extras import RealDictCursor
import datetime

class DatabaseManager:
    def __init__(self, db_config):
        self.db_config = db_config
        self.init_database()
    
    def get_connection(self):
        """获取数据库连接"""
        conn = psycopg2.connect(
            host=self.db_config['host'],
            port=self.db_config['port'],
            database=self.db_config['database'],
            user=self.db_config['user'],
            password=self.db_config['password']
        )
        return conn
    
    def init_database(self):
        """初始化数据库表"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # 创建车辆进出记录表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vehicle_records (
                    id SERIAL PRIMARY KEY,
                    plate_number VARCHAR(50) NOT NULL,
                    entry_time TIMESTAMP NOT NULL,
                    exit_time TIMESTAMP,
                    parking_space VARCHAR(20),
                    duration_minutes INTEGER,
                    fee DECIMAL(10,2),
                    status VARCHAR(10) DEFAULT 'in',
                    operator_id INTEGER
                )
            ''')
            
            # 创建停车位状态表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS parking_spaces (
                    space_id VARCHAR(20) PRIMARY KEY,
                    status VARCHAR(20) DEFAULT 'available',
                    vehicle_plate VARCHAR(50),
                    last_updated TIMESTAMP
                )
            ''')
            
            # 创建系统日志表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_logs (
                    id SERIAL PRIMARY KEY,
                    timestamp TIMESTAMP NOT NULL,
                    log_type VARCHAR(50) NOT NULL,
                    message VARCHAR(500) NOT NULL,
                    details TEXT,
                    user_id INTEGER
                )
            ''')
            
            # 初始化停车位（创建20个默认车位）
            for i in range(1, 21):
                space_id = f"A{i:02d}"
                cursor.execute('''
                    INSERT INTO parking_spaces (space_id, status, last_updated)
                    SELECT %s, 'available', CURRENT_TIMESTAMP
                    WHERE NOT EXISTS (SELECT 1 FROM parking_spaces WHERE space_id = %s)
                ''', (space_id, space_id))
            
            conn.commit()
            conn.close()
            print("PostgreSQL数据库初始化完成")
        except Exception as e:
            print(f"初始化数据库失败: {e}")
    
    def add_vehicle_record(self, plate_number, parking_space=None, operator_id=None):
        """添加车辆进入记录"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            entry_time = datetime.datetime.now()
            cursor.execute('''
                INSERT INTO vehicle_records (plate_number, entry_time, parking_space, status, operator_id)
                VALUES (%s, %s, %s, 'in', %s)
            ''', (plate_number, entry_time, parking_space, operator_id))
            
            # 更新停车位状态
            if parking_space:
                cursor.execute('''
                    UPDATE parking_spaces 
                    SET status = 'occupied', vehicle_plate = %s, last_updated = %s
                    WHERE space_id = %s
                ''', (plate_number, entry_time, parking_space))
            
            conn.commit()
            conn.close()
            self.log_system_event("VEHICLE_ENTRY", f"车辆 {plate_number} 进入停车位 {parking_space}", user_id=operator_id)
        except Exception as e:
            print(f"添加车辆记录失败: {e}")
    
    def update_vehicle_exit(self, plate_number, fee=0, operator_id=None):
        """更新车辆离开记录"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            exit_time = datetime.datetime.now()
            
            # 查找最近的进入记录
            cursor.execute('''
                SELECT id, entry_time, parking_space FROM vehicle_records 
                WHERE plate_number = %s AND status = 'in' 
                ORDER BY entry_time DESC LIMIT 1
            ''', (plate_number,))
            
            row = cursor.fetchone()
            if row:
                record_id, entry_time, parking_space = row
                duration = (exit_time - entry_time).total_seconds() / 60
                
                cursor.execute('''
                    UPDATE vehicle_records 
                    SET exit_time = %s, duration_minutes = %s, fee = %s, status = 'out'
                    WHERE id = %s
                ''', (exit_time, duration, fee, record_id))
                
                # 释放停车位
                if parking_space:
                    cursor.execute('''
                        UPDATE parking_spaces 
                        SET status = 'available', vehicle_plate = NULL, last_updated = %s
                        WHERE space_id = %s
                    ''', (exit_time, parking_space))
                
                conn.commit()
                self.log_system_event("VEHICLE_EXIT", f"车辆 {plate_number} 离开，费用: {fee}元", user_id=operator_id)
            
            conn.close()
        except Exception as e:
            print(f"更新车辆记录失败: {e}")
    
    def get_parking_statistics(self):
        """获取停车统计信息"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # 今日收入
            cursor.execute('''
                SELECT COALESCE(SUM(fee), 0) FROM vehicle_records 
                WHERE DATE(exit_time) = CURRENT_DATE AND fee IS NOT NULL
            ''')
            today_income = float(cursor.fetchone()[0])
            
            # 当前停车车辆数
            cursor.execute('''
                SELECT COUNT(*) FROM vehicle_records WHERE status = 'in'
            ''')
            current_vehicles = cursor.fetchone()[0]
            
            # 可用停车位
            cursor.execute('''
                SELECT COUNT(*) FROM parking_spaces WHERE status = 'available'
            ''')
            available_spaces = cursor.fetchone()[0]
            
            # 总停车位
            cursor.execute('''
                SELECT COUNT(*) FROM parking_spaces
            ''')
            total_spaces = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                'today_income': today_income,
                'current_vehicles': current_vehicles,
                'available_spaces': available_spaces,
                'total_spaces': total_spaces
            }
        except Exception as e:
            print(f"获取统计信息失败: {e}")
            return {
                'today_income': 0,
                'current_vehicles': 0,
                'available_spaces': 0,
                'total_spaces': 20
            }
    
    def get_all_records(self, limit=100):
        """获取所有车辆记录"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            cursor.execute('''
                SELECT id, plate_number, 
                       to_char(entry_time, 'YYYY-MM-DD HH24:MI:SS') as entry_time,
                       to_char(exit_time, 'YYYY-MM-DD HH24:MI:SS') as exit_time,
                       parking_space, duration_minutes, fee, status
                FROM vehicle_records 
                ORDER BY entry_time DESC
                LIMIT %s
            ''', (limit,))
            
            records = cursor.fetchall()
            conn.close()
            return records
        except Exception as e:
            print(f"获取记录失败: {e}")
            return []
    
    def log_system_event(self, log_type, message, details=None, user_id=None):
        """记录系统事件"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO system_logs (timestamp, log_type, message, details, user_id)
                VALUES (CURRENT_TIMESTAMP, %s, %s, %s, %s)
            ''', (log_type, message, details, user_id))
            
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"记录系统事件时出错: {e}")