import sqlite3
import hashlib
import datetime

class UserAuthentication:
    def __init__(self, db_path="parking_system.db"):
        self.db_path = db_path
        self.current_user = None
        self.init_user_table()
    
    def init_user_table(self):
        """初始化用户表"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                email TEXT,
                role TEXT DEFAULT 'user',
                created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_login DATETIME
            )
        ''')
        
        # 创建默认管理员账户
        cursor.execute('''
            INSERT OR IGNORE INTO users (username, password_hash, email, role)
            VALUES (?, ?, ?, ?)
        ''', ('admin', self.hash_password('admin123'), 'admin@parking.com', 'admin'))
        
        conn.commit()
        conn.close()
    
    def hash_password(self, password):
        """密码加密"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register_user(self, username, password, email=None):
        """用户注册"""
        if not username or not password:
            return False, "用户名和密码不能为空"
        
        if len(username) < 3:
            return False, "用户名至少需要3个字符"
        
        if len(password) < 6:
            return False, "密码至少需要6个字符"
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            password_hash = self.hash_password(password)
            cursor.execute('''
                INSERT INTO users (username, password_hash, email)
                VALUES (?, ?, ?)
            ''', (username, password_hash, email))
            
            conn.commit()
            conn.close()
            return True, "注册成功"
        except sqlite3.IntegrityError:
            conn.close()
            return False, "用户名已存在"
        except Exception as e:
            conn.close()
            return False, f"注册失败: {str(e)}"
    
    def login_user(self, username, password):
        """用户登录"""
        if not username or not password:
            return False, "用户名和密码不能为空"
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, username, password_hash, role FROM users 
            WHERE username = ?
        ''', (username,))
        
        user = cursor.fetchone()
        
        if user and user[2] == self.hash_password(password):
            self.current_user = {
                'id': user[0],
                'username': user[1],
                'role': user[3]
            }
            
            # 更新最后登录时间
            cursor.execute('''
                UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
            ''', (user[0],))
            conn.commit()
            
            conn.close()
            return True, "登录成功"
        else:
            conn.close()
            return False, "用户名或密码错误"
    
    def logout_user(self):
        """用户登出"""
        self.current_user = None
        return True, "登出成功"
    
    def is_logged_in(self):
        """检查是否已登录"""
        return self.current_user is not None
    
    def get_current_user(self):
        """获取当前用户信息"""
        return self.current_user
    
    def change_password(self, username, old_password, new_password):
        """修改密码"""
        success, message = self.login_user(username, old_password)
        if not success:
            return False, "原密码错误"
        
        if len(new_password) < 6:
            return False, "新密码至少需要6个字符"
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            new_password_hash = self.hash_password(new_password)
            cursor.execute('''
                UPDATE users SET password_hash = ? WHERE username = ?
            ''', (new_password_hash, username))
            
            conn.commit()
            conn.close()
            return True, "密码修改成功"
        except Exception as e:
            conn.close()
            return False, f"密码修改失败: {str(e)}"