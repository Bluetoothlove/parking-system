import psycopg2
from psycopg2.extras import RealDictCursor
import hashlib
import datetime

class UserAuthentication:
    def __init__(self, db_config):
        self.db_config = db_config
        self.current_user = None
        self.init_user_table()
    
    def get_connection(self):
        """获取数据库连接"""
        conn = psycopg2.connect(
            host=self.db_config['host'],
            port=self.db_config['port'],
            database=self.db_config['database'],
            user=self.db_config['user'],
            password=self.db_config['password']
        )
        return conn
    
    def init_user_table(self):
        """初始化用户表"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # 创建用户表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password_hash VARCHAR(100) NOT NULL,
                    email VARCHAR(100),
                    role VARCHAR(20) DEFAULT 'user',
                    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login TIMESTAMP
                )
            ''')
            
            # 检查admin用户是否存在
            cursor.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
            if cursor.fetchone()[0] == 0:
                # 创建默认管理员账户
                cursor.execute('''
                    INSERT INTO users (username, password_hash, email, role)
                    VALUES (%s, %s, %s, %s)
                ''', ('admin', self.hash_password('admin123'), 'admin@parking.com', 'admin'))
            
            conn.commit()
            conn.close()
            print("PostgreSQL用户表初始化完成")
        except Exception as e:
            print(f"初始化用户表失败: {e}")
    
    def hash_password(self, password):
        """密码加密"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register_user(self, username, password, email=None):
        """用户注册"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # 检查用户名是否已存在
            cursor.execute("SELECT COUNT(*) FROM users WHERE username = %s", (username,))
            if cursor.fetchone()[0] > 0:
                conn.close()
                return False, "用户名已存在"
            
            password_hash = self.hash_password(password)
            cursor.execute('''
                INSERT INTO users (username, password_hash, email)
                VALUES (%s, %s, %s)
            ''', (username, password_hash, email))
            
            conn.commit()
            conn.close()
            return True, "注册成功"
        except Exception as e:
            return False, f"注册失败: {str(e)}"
    
    def login_user(self, username, password):
        """用户登录"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            cursor.execute('''
                SELECT id, username, password_hash, role FROM users 
                WHERE username = %s
            ''', (username,))
            
            user = cursor.fetchone()
            
            if user and user['password_hash'] == self.hash_password(password):
                user_data = {
                    'id': user['id'],
                    'username': user['username'],
                    'role': user['role']
                }
                self.current_user = user_data
                
                # 更新最后登录时间
                cursor.execute('''
                    UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = %s
                ''', (user['id'],))
                conn.commit()
                
                conn.close()
                return True, "登录成功", user_data
            else:
                conn.close()
                return False, "用户名或密码错误", None
        except Exception as e:
            return False, f"登录失败: {str(e)}", None
    
    def get_user_by_username(self, username):
        """通过用户名获取用户信息"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            cursor.execute('''
                SELECT id, username, role, email, created_date, last_login
                FROM users WHERE username = %s
            ''', (username,))
            
            user = cursor.fetchone()
            conn.close()
            
            return user
        except Exception as e:
            print(f"获取用户信息失败: {e}")
            return None