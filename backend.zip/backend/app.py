from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import os
import cv2
import numpy as np
from werkzeug.utils import secure_filename
import datetime
import uuid

from models.yolo_model import YOLOModel
from models.plate_recognition import PlateRecognizer
from models.database_postgres import DatabaseManager
from auth.auth_postgres import UserAuthentication

app = Flask(__name__)
CORS(app, supports_credentials=True)

# 配置
app.config['SECRET_KEY'] = 'parking-system-secret-key-2024'
app.config['JWT_SECRET_KEY'] = 'jwt-secret-key-parking-2024'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'mp4', 'avi', 'mov'}

jwt = JWTManager(app)

# 确保上传目录存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# PostgreSQL配置
POSTGRES_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'parkingsystem',
    'user': 'postgres', 
    'password': '200516'  
}

# 初始化各个模块
db_manager = DatabaseManager(POSTGRES_CONFIG)
auth_manager = UserAuthentication(POSTGRES_CONFIG)
yolo_model = YOLOModel()
plate_recognizer = PlateRecognizer()


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# ========== 用户认证接口 ==========
@app.route('/api/auth/register', methods=['POST', 'OPTIONS'])
def register():
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '无效的请求数据'}), 400
            
        username = data.get('username')
        password = data.get('password')
        email = data.get('email', '')
        
        if not username or not password:
            return jsonify({'success': False, 'message': '用户名和密码不能为空'}), 400
        
        success, message = auth_manager.register_user(username, password, email)
        if success:
            return jsonify({'success': True, 'message': message}), 201
        return jsonify({'success': False, 'message': message}), 400
    except Exception as e:
        print(f"注册错误: {e}")
        return jsonify({'success': False, 'message': f'注册失败: {str(e)}'}), 500

@app.route('/api/auth/login', methods=['POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '无效的请求数据'}), 400
            
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'success': False, 'message': '用户名和密码不能为空'}), 400
        
        success, message, user_data = auth_manager.login_user(username, password)
        if success:
            access_token = create_access_token(
                identity=username,
                additional_claims={
                    'user_id': user_data['id'], 
                    'role': user_data['role']
                }
            )
            return jsonify({
                'success': True,
                'message': message,
                'access_token': access_token,
                'user': user_data
            })
        return jsonify({'success': False, 'message': message}), 401
    except Exception as e:
        print(f"登录错误: {e}")
        return jsonify({'success': False, 'message': f'登录失败: {str(e)}'}), 500

@app.route('/api/auth/logout', methods=['POST', 'OPTIONS'])
@jwt_required()
def logout():
    if request.method == 'OPTIONS':
        return '', 200
    return jsonify({'success': True, 'message': '退出成功'})

@app.route('/api/auth/me', methods=['GET', 'OPTIONS'])
@jwt_required()
def get_current_user():
    if request.method == 'OPTIONS':
        return '', 200
    
    current_user = get_jwt_identity()
    user_data = auth_manager.get_user_by_username(current_user)
    if user_data:
        return jsonify({'success': True, 'user': user_data})
    return jsonify({'success': False, 'message': '用户不存在'}), 401

# ========== 停车位检测接口 ==========
@app.route('/api/parking/detect', methods=['POST', 'OPTIONS'])
@jwt_required()
def detect_parking():
    if request.method == 'OPTIONS':
        return '', 200
    
    if 'image' not in request.files:
        return jsonify({'success': False, 'message': '请选择图片文件'}), 400
    
    file = request.files['image']
    if file.filename == '':
        return jsonify({'success': False, 'message': '请选择文件'}), 400
    
    if file and allowed_file(file.filename):
        # 保存上传的文件
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{uuid.uuid4()}_{filename}")
        file.save(filepath)
        
        # 读取并处理图像
        img = cv2.imread(filepath)
        if img is None:
            return jsonify({'success': False, 'message': '无效的图片文件'}), 400
        
        # 进行检测
        result_img, results = yolo_model.predict_and_detect(img, conf=0.5)
        
        # 保存结果
        result_filename = f"result_{uuid.uuid4()}.jpg"
        result_path = os.path.join(app.config['UPLOAD_FOLDER'], result_filename)
        cv2.imwrite(result_path, result_img)
        
        # 获取检测信息
        detected_objects = []
        if results and len(results) > 0:
            for result in results:
                for box in result.boxes:
                    detected_objects.append({
                        'class': result.names[int(box.cls[0])],
                        'confidence': float(box.conf[0]),
                        'bbox': box.xyxy[0].tolist()
                    })
        
        # 记录到数据库
        current_user = get_jwt_identity()
        user_info = auth_manager.get_user_by_username(current_user)
        db_manager.log_system_event(
            'PARKING_DETECTION',
            f'检测到 {len(detected_objects)} 个停车位',
            user_id=user_info['id'] if user_info else None
        )
        
        return jsonify({
            'success': True,
            'result_image': f'/api/images/{result_filename}',
            'detected_objects': detected_objects,
            'count': len(detected_objects)
        })
    
    return jsonify({'success': False, 'message': '不支持的文件类型'}), 400

# ========== 车牌识别接口 ==========
@app.route('/api/plate/recognize', methods=['POST', 'OPTIONS'])
@jwt_required()
def recognize_plate():
    if request.method == 'OPTIONS':
        return '', 200
    
    if 'image' not in request.files:
        return jsonify({'success': False, 'message': '请选择图片文件'}), 400
    
    file = request.files['image']
    if file.filename == '':
        return jsonify({'success': False, 'message': '请选择文件'}), 400
    
    if file and allowed_file(file.filename):
        # 保存上传的文件
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{uuid.uuid4()}_{filename}")
        file.save(filepath)
        
        # 读取图像
        img = cv2.imread(filepath)
        if img is None:
            return jsonify({'success': False, 'message': '无效的图片文件'}), 400
        
        # 进行车牌识别
        result_img, plates = plate_recognizer.recognize(img)
        
        # 保存结果
        result_filename = f"plate_result_{uuid.uuid4()}.jpg"
        result_path = os.path.join(app.config['UPLOAD_FOLDER'], result_filename)
        cv2.imwrite(result_path, result_img)
        
        # 记录到数据库
        current_user = get_jwt_identity()
        user_info = auth_manager.get_user_by_username(current_user)
        for plate in plates:
            db_manager.add_vehicle_record(
                plate,
                "A01",  # 示例停车位
                user_info['id'] if user_info else None
            )
        
        return jsonify({
            'success': True,
            'result_image': f'/api/images/{result_filename}',
            'plates': plates,
            'count': len(plates)
        })
    
    return jsonify({'success': False, 'message': '不支持的文件类型'}), 400

# ========== 统计信息接口 ==========
@app.route('/api/statistics', methods=['GET', 'OPTIONS'])
@jwt_required()
def get_statistics():
    if request.method == 'OPTIONS':
        return '', 200
    
    stats = db_manager.get_parking_statistics()
    return jsonify({'success': True, 'statistics': stats})

# ========== 车辆记录接口 ==========
@app.route('/api/records', methods=['GET', 'OPTIONS'])
@jwt_required()
def get_records():
    if request.method == 'OPTIONS':
        return '', 200
    
    records = db_manager.get_all_records()
    return jsonify({'success': True, 'records': records})

@app.route('/api/records/entry', methods=['POST', 'OPTIONS'])
@jwt_required()
def add_entry():
    if request.method == 'OPTIONS':
        return '', 200
    
    data = request.get_json()
    plate_number = data.get('plate_number')
    parking_space = data.get('parking_space')
    
    if not plate_number:
        return jsonify({'success': False, 'message': '请输入车牌号'}), 400
    
    current_user = get_jwt_identity()
    user_info = auth_manager.get_user_by_username(current_user)
    db_manager.add_vehicle_record(
        plate_number,
        parking_space,
        user_info['id'] if user_info else None
    )
    
    return jsonify({'success': True, 'message': '入场登记成功'})

@app.route('/api/records/exit', methods=['POST', 'OPTIONS'])
@jwt_required()
def add_exit():
    if request.method == 'OPTIONS':
        return '', 200
    
    data = request.get_json()
    plate_number = data.get('plate_number')
    fee = data.get('fee', 0)
    
    if not plate_number:
        return jsonify({'success': False, 'message': '请输入车牌号'}), 400
    
    current_user = get_jwt_identity()
    user_info = auth_manager.get_user_by_username(current_user)
    db_manager.update_vehicle_exit(
        plate_number,
        float(fee),
        user_info['id'] if user_info else None
    )
    
    return jsonify({'success': True, 'message': '出场登记成功'})

# ========== 图像服务接口 ==========
@app.route('/api/images/<filename>', methods=['GET'])
def get_image(filename):
    return send_file(os.path.join(app.config['UPLOAD_FOLDER'], filename))

# ========== 视频停车位检测接口 ==========
@app.route('/api/parking/detect-video', methods=['POST', 'OPTIONS'])
@jwt_required()
def detect_parking_video():
    if request.method == 'OPTIONS':
        return '', 200
    
    if 'video' not in request.files:
        return jsonify({'success': False, 'message': '请选择视频文件'}), 400
    
    file = request.files['video']
    if file.filename == '':
        return jsonify({'success': False, 'message': '请选择文件'}), 400
    
    # 保存上传的视频
    filename = secure_filename(file.filename)
    video_path = os.path.join(app.config['UPLOAD_FOLDER'], f"video_{uuid.uuid4()}_{filename}")
    file.save(video_path)
    
    # 处理视频
    cap = cv2.VideoCapture(video_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # 创建输出视频
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], f"result_video_{uuid.uuid4()}.mp4")
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    frame_count = 0
    detections_per_frame = []
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # 检测
        result_frame, results = yolo_model.predict_and_detect(frame, conf=0.5)
        out.write(result_frame)
        
        # 记录检测信息
        frame_detections = []
        if results and len(results) > 0:
            for result in results:
                for box in result.boxes:
                    frame_detections.append({
                        'class': result.names[int(box.cls[0])],
                        'confidence': float(box.conf[0])
                    })
        
        detections_per_frame.append({
            'frame': frame_count,
            'count': len(frame_detections),
            'objects': list(set([d['class'] for d in frame_detections]))
        })
        
        frame_count += 1
    
    cap.release()
    out.release()
    
    # 清理临时视频文件
    os.remove(video_path)
    
    return jsonify({
        'success': True,
        'result_video': f'/api/images/{os.path.basename(output_path)}',
        'frames_processed': frame_count,
        'total_detections': sum(len(d['objects']) for d in detections_per_frame),
        'detections_per_frame': detections_per_frame
    })

# ========== 视频车牌识别接口 ==========
@app.route('/api/plate/recognize-video', methods=['POST', 'OPTIONS'])
@jwt_required()
def recognize_plate_video():
    if request.method == 'OPTIONS':
        return '', 200
    
    if 'video' not in request.files:
        return jsonify({'success': False, 'message': '请选择视频文件'}), 400
    
    file = request.files['video']
    if file.filename == '':
        return jsonify({'success': False, 'message': '请选择文件'}), 400
    
    # 保存上传的视频
    filename = secure_filename(file.filename)
    video_path = os.path.join(app.config['UPLOAD_FOLDER'], f"video_{uuid.uuid4()}_{filename}")
    file.save(video_path)
    
    # 处理视频
    cap = cv2.VideoCapture(video_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # 创建输出视频
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], f"result_video_{uuid.uuid4()}.mp4")
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    frame_count = 0
    all_plates = set()
    plates_per_frame = []
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # 识别
        result_frame, plates = plate_recognizer.recognize(frame)
        out.write(result_frame)
        
        # 记录识别信息
        all_plates.update(plates)
        plates_per_frame.append({
            'frame': frame_count,
            'plates': plates
        })
        
        frame_count += 1
    
    cap.release()
    out.release()
    
    # 清理临时视频文件
    os.remove(video_path)
    
    # 记录到数据库
    current_user = get_jwt_identity()
    user_info = auth_manager.get_user_by_username(current_user)
    for plate in all_plates:
        db_manager.add_vehicle_record(plate, None, user_info['id'] if user_info else None)
    
    return jsonify({
        'success': True,
        'result_video': f'/api/images/{os.path.basename(output_path)}',
        'frames_processed': frame_count,
        'unique_plates': list(all_plates),
        'plates_per_frame': plates_per_frame
    })

if __name__ == '__main__':
    print("="*50)
    print("智慧停车系统 - 后端服务")
    print("="*50)
    print(f"服务地址: http://127.0.0.1:5000")
    print(f"局域网访问: http://{app.config['SERVER_NAME'] if app.config.get('SERVER_NAME') else '10.20.253.203'}:5000")
    print("="*50)
    print("默认管理员账号: admin")
    print("默认密码: admin123")
    print("="*50)
    app.run(debug=True, host='0.0.0.0', port=5000)